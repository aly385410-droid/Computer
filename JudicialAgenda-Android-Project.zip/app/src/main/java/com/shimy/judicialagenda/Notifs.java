package com.shimy.judicialagenda;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** جدولة تنبيهات الجلسات والتذكيرات (تعمل والتطبيق مغلق) */
public class Notifs {
    static final String CH = "agenda_sessions";
    static final String PREF = "notifs";
    static final int BASE = 7000;
    static final int MAXN = 60;

    /** يستبدل كل التنبيهات المجدولة بالقائمة الجديدة: [{id,ts,title,text}] */
    public static void schedule(Context ctx, String json) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            sp.edit().putString("list", json == null ? "[]" : json).apply();
            apply(ctx, json == null ? "[]" : json);
        } catch (Throwable e) {
            // لا نُسقط التطبيق بسبب تنبيه
        }
    }

    /** إعادة الجدولة من آخر قائمة محفوظة (بعد إعادة تشغيل الهاتف) */
    public static void reschedule(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            apply(ctx, sp.getString("list", "[]"));
        } catch (Throwable e) {
        }
    }

    private static PendingIntent pi(Context ctx, int code, String title, String text) {
        Intent i = new Intent(ctx, Notifs.NotifReceiver.class);
        i.setAction("com.shimy.judicialagenda.NOTIF");
        i.putExtra("title", title == null ? "" : title);
        i.putExtra("text", text == null ? "" : text);
        i.putExtra("code", code);
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void apply(Context ctx, String json) throws Exception {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        int old = sp.getInt("n", 0);
        for (int k = 0; k < old; k++) {
            am.cancel(pi(ctx, BASE + k, "", ""));
        }
        JSONArray arr = new JSONArray(json);
        long now = System.currentTimeMillis();
        int n = 0;
        for (int k = 0; k < arr.length() && n < MAXN; k++) {
            JSONObject o = arr.getJSONObject(k);
            long ts = o.optLong("ts", 0);
            if (ts <= now + 5000) continue;
            PendingIntent p = pi(ctx, BASE + n, o.optString("title"), o.optString("text"));
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, p);
            n++;
        }
        sp.edit().putInt("n", n).apply();
    }

    static void show(Context ctx, String title, String text, int code) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "تنبيهات الجلسات والتذكيرات", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(ctx, code, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CH) : new Notification.Builder(ctx);
        b.setSmallIcon(ctx.getApplicationInfo().icon)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(content);
        nm.notify(code, b.build());
    }

    public static class NotifReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            try {
                show(ctx, intent.getStringExtra("title"), intent.getStringExtra("text"), intent.getIntExtra("code", 1));
            } catch (Throwable e) {
            }
        }
    }

    public static class BootReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            reschedule(ctx);
        }
    }
}
